<?php

namespace App\Http\Livewire\Client;

use Livewire\Component;

class QuotationForm extends Component
{
    public function render()
    {
        return view('livewire.client.quotation-form');
    }
}
