<?php

return [
  'title' => 'GodProm',
  'tagline' => 'Export your packages',
  'description' => 'GodProm is a free online platform for sending packages.',
];