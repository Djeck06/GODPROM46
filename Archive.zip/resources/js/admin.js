window._ = require("lodash");
require("alpinejs");
