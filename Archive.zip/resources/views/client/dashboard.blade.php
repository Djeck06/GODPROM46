@extends('client.global')

@section('content')

@endsection