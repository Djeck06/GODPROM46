<footer class="w-full bg-white text-right p-4">
    Built by <a target="_blank" href="https://godwinelitcha.com" class="underline">Godwin Elitcha</a>.
</footer>
