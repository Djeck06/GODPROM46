<header class="bg-transparent sticky-bar pt-4 z-30">
    <div class="container mx-auto bg-transparent">
        <div class="flex justify-between h-16 items-center">
            <x-application-logo />
            
            @include('partials.app.nav.menu')

            @include('partials.app.nav.user')
        </div>
    </div>

</header>
