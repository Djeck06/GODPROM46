<a href="{{ route('home', app()->getLocale()) }}" class="text-xl lg:text-2xl font-bold cursor-pointer">
    <img src="{{ asset('images/logo-Godprom.png') }}" alt="logo Godprom" class="h-16">
</a>
