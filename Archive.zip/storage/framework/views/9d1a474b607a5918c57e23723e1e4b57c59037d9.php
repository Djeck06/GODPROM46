<header class="bg-transparent sticky-bar pt-4 z-30">
    <div class="container mx-auto bg-transparent">
        <div class="flex justify-between h-16 items-center">
            <a href="<?php echo e(route('home', app()->getLocale())); ?>" class="text-xl lg:text-2xl font-bold cursor-pointer">
                <img src="<?php echo e(asset('images/logo-Godprom.png')); ?>" alt="logo Godprom" class="h-16">
            </a>
            <div class="flex items-center space-x-8">
                <ul class="hidden md:flex justify-around space-x-4">
                    <li class="py-4">
                        <a href="<?php echo e(route('home', app()->getLocale())); ?>"
                            class="hover:text-blue-600 text-gray-500 text-sm font-semibold uppercase"><?php echo e(__('Home')); ?></a>
                    </li>
                    <li class="py-4">
                        <a href="#"
                            class="hover:text-blue-600 text-gray-500 text-sm font-semibold uppercase"><?php echo e(__('How it works?')); ?></a>
                    </li>
                    <li class="py-4">
                        <a href="#"
                            class="hover:text-blue-600 text-gray-500 text-sm font-semibold uppercase"><?php echo e(__('FAQ')); ?></a>
                    </li class="py-4">
                    <li class="py-4">
                        <a href="<?php echo e(route('contact', app()->getLocale())); ?>"
                            class="hover:text-blue-600 text-gray-500 text-sm font-semibold uppercase"><?php echo e(__('Contact')); ?></a>
                    </li>
                </ul>
            </div>
            <div class="flex space-x-4 items-center">
                <?php if(Auth::check() && Auth::user()->type == 'client'): ?>
                    <a href="#"
                        class="border border-blue-500 px-4 py-2 rounded text-blue-500 text-sm font-semibold"><?php echo e(__('Send')); ?></a>
                <?php endif; ?>

                <?php if(Auth::check() && Auth::user()->type == 'transporter'): ?>
                    <a href="#"
                        class="border border-blue-500 px-4 py-2 rounded text-blue-500 text-sm font-semibold"><?php echo e(__('Transport')); ?></a>
                <?php endif; ?>

                <div class="hidden sm:flex sm:items-center sm:ml-6">
                    <?php echo $__env->make('layouts.lang-switcher', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>

                <?php if(auth()->guard()->guest()): ?>
                    <a href="<?php echo e(route('login')); ?>"
                        class="border border-blue-500 px-4 py-2 rounded text-blue-500 text-sm font-semibold"><?php echo e(__('Login')); ?></a>
                    <a href="<?php echo e(route('register')); ?>"
                        class="px-4 py-2 rounded text-white bg-blue-500 hover:bg-blue-700 text-sm font-semibold"><?php echo e(__('Register')); ?></a>
                <?php endif; ?>

                <?php if(auth()->guard()->check()): ?>
                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.dropdown','data' => ['align' => 'right','width' => '48']]); ?>
<?php $component->withName('dropdown'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['align' => 'right','width' => '48']); ?>
                         <?php $__env->slot('trigger', null, []); ?> 
                            <button
                                class="flex items-center text-sm font-medium text-gray-500 hover:text-gray-700 hover:border-gray-300 focus:outline-none focus:text-gray-700 focus:border-gray-300 transition duration-150 ease-in-out">
                                <div><?php echo e(Auth::user()->full_name); ?></div>

                                <div class="ml-1">
                                    <svg class="fill-current h-4 w-4" xmlns="http://www.w3.org/2000/svg"
                                        viewBox="0 0 20 20">
                                        <path fill-rule="evenodd"
                                            d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z"
                                            clip-rule="evenodd" />
                                    </svg>
                                </div>
                            </button>
                         <?php $__env->endSlot(); ?>

                         <?php $__env->slot('content', null, []); ?> 
                            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.responsive-nav-link','data' => ['href' => '#']]); ?>
<?php $component->withName('responsive-nav-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['href' => '#']); ?>Mon Profil <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                            <form method="POST" action="<?php echo e(route('logout')); ?>">
                                <?php echo csrf_field(); ?>

                                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.responsive-nav-link','data' => ['href' => route('logout'),'onclick' => 'event.preventDefault();
                                    this.closest(\'form\').submit();']]); ?>
<?php $component->withName('responsive-nav-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('logout')),'onclick' => 'event.preventDefault();
                                    this.closest(\'form\').submit();']); ?>
                                    <?php echo e(__('Log Out')); ?>

                                 <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                            </form>
                         <?php $__env->endSlot(); ?>
                     <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                <?php endif; ?>

            </div>
        </div>
    </div>

</header>
<?php /**PATH /Users/godwin/Sites/godprom/resources/views/layouts/nav.blade.php ENDPATH**/ ?>