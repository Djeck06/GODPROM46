<?php return array (
  'client.quotation-form' => 'App\\Http\\Livewire\\Client\\QuotationForm',
);